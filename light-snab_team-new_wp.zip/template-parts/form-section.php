<div class="container">
  <form action="" class="form-section__form">
    <div class="form-section__form-title">Форма обратной связи</div>
    <div class="form-section__form-wrapper">
      <div class="form-section__form-input-wrap">
        <input type="text" name="name" placeholder="Имя*">
        <input type="tel" name="tel" placeholder="Телефон*">
        <input type="email" name="email" placeholder="E-mail*">
      </div>
      <textarea name="message" id="" placeholder="Сообщение"></textarea>
    </div>
    <a href="#" class="button-submit uniSendBtn" data-formid="Отправка с секции Форма обратной связи" data-mailmsg="Отправка с секции Форма обратной связи">Отправить</a>
    <div class="form-section__form-note">*Нажимая кнопку «Отправить» Вы принимаете условия политики конфиденциальности в отношении обработки персональных данных</div>
  </form>
</div>