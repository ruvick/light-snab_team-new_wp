<!-- <?php get_header(); ?>

	<?php get_template_part('template-parts/block-menu');?>

	<?php get_template_part('template-parts/header-category');?>

	<?php get_template_part('template-parts/category-page-section');?>

	<?php get_template_part('template-parts/products-category-section');?>

	<?php get_template_part('template-parts/category-page-tags');?>

<?php get_footer(); ?>  -->