<!-- В этом файле описываем все  всплывающие окна -->

<div style="display: none;">
    <div class="box-modal" id="messgeModal">
        <div class="box-modal_close arcticmodal-close">закрыть</div>
        <div class = "modalline" id = "lineIcon">
    </div>
    
    <div class = "modalline" id = "lineMsg">
    </div>
    </div>
  </div>

  <div style="display: none;">
    <div class="box-modal" id="brand-modal">
        <div class="box-modal_close arcticmodal-close"></div>
        <div class = "modalline" id = "lineIcon">
    </div>
    
    <div class = "brand-modal-wrapper" id = "lineMsg">
      <div class="brand-modal__photo"></div>
      <div class="brand-modal__content"></div>
    </div>
    </div>
  </div>

  <div style="display: none;">
    <div class="box-modal" id="order-modal">
        <div class="box-modal_close arcticmodal-close">закрыть</div>
        <div class="box-modal_close arcticmodal-close"></div>
        <div class = "modalline" id = "lineIcon">
          <form action="">
            <h2>Стать нашим партнером</h2>
            <input type="text" name="name" placeholder="Ваше имя">
            <input type="tel" name="tel" placeholder="Ваш телефон">
            <input type="hidden" name="partner">
            <a href="#" class="uniSendBtn-2">Отправить</a>
          </form>
        </div>
    
    <div class = "modalline" id = "lineMsg">
    </div>
    </div>
  </div>
  <div style="display: none;">
    <div class="box-modal" id="question-modal">
        <div class="box-modal_close arcticmodal-close">закрыть</div>
        <div class="box-modal_close arcticmodal-close"></div>
        <div class = "modalline" id = "lineIcon">
          <form action="">
            <h2>Задать вопрос</h2>
            <input type="text" name="name" placeholder="Ваше имя">
            <input type="tel" name="tel" placeholder="Ваш телефон">
            <a href="#" class="more-link uniSendBtn">Отправить</a>
          </form>
        </div>
    
    <div class = "modalline" id = "lineMsg">
    </div>
    </div>
  </div>